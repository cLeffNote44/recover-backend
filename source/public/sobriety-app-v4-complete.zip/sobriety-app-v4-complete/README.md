# Recovery Journey - Sobriety Tracker v4.0

**A comprehensive recovery companion app with mood tracking, relapse prevention planning, meditation, and more.**

---

## 🎉 What's New in Version 4

This major update adds **four powerful features** to support your recovery journey:

1. **😊 Mood Tracking** - Track emotional state with daily check-ins and identify patterns
2. **🛡️ Relapse Prevention Plan** - Build a personalized safety plan with warning signs and action levels
3. **🌙 Dark Mode** - Toggle between light and dark themes for comfortable viewing
4. **🧘 Meditation Tracker** - Log meditation sessions with built-in timer and streak tracking

---

## 📦 What's Included

- **sobriety-app-v4.jsx** - Main React component (120KB, 2,500+ lines)
- **sobriety-app-v4-demo.html** - Ready-to-use demo file
- **V4_FEATURES.md** - Comprehensive feature documentation
- **README.md** - This file

---

## 🚀 Quick Start

### Option 1: Demo File (Fastest)
1. Open `sobriety-app-v4-demo.html` in your web browser
2. Set your sobriety date
3. Start using the app immediately!

### Option 2: React Integration
1. Copy code from `sobriety-app-v4.jsx`
2. Paste into your React project
3. Install dependencies:
   ```bash
   npm install react react-dom lucide-react
   ```
4. Import and use the component

---

## ✨ Complete Feature List

### Core Features (v1-v3)
- ✅ Days sober counter with milestone tracking
- ✅ Daily check-in system with streak tracking
- ✅ Trigger & craving log with pattern analysis
- ✅ Emergency support with quick-dial and coping strategies
- ✅ Meeting tracker for AA/NA attendance
- ✅ Growth logs for personal development
- ✅ Challenge tracker for difficult situations
- ✅ Gratitude journal
- ✅ Calendar with event scheduling
- ✅ Support network contacts
- ✅ Analytics dashboard with charts
- ✅ Data export/import (JSON backup)
- ✅ localStorage persistence

### New in v4
- ✅ **Mood tracking** with 5-level emoji scale
- ✅ **Mood trends** (improving/declining/stable)
- ✅ **Relapse prevention plan builder** with 5 zones
- ✅ **Dark mode** with persistent preference
- ✅ **Meditation timer** with start/pause/resume
- ✅ **Meditation streak** tracking
- ✅ **9 meditation types** to choose from
- ✅ **Enhanced analytics** with mood and meditation data

---

## 📱 App Structure

### 8-Tab Navigation

1. **Home** 🏠
   - Days sober counter
   - Milestone display
   - Motivational quotes
   - Quick stats
   - Dark mode toggle
   - Emergency support button
   - Prevention plan button
   - Export/import data

2. **Check-In** ✅
   - Daily check-in button
   - Mood selector (5 emotions)
   - Streak counter
   - 7-day visual calendar
   - Monthly statistics
   - Emergency support access

3. **Cravings** 🎯
   - Log craving with intensity (1-10)
   - Select trigger type
   - Document coping strategy
   - Mark if overcame
   - Pattern analysis (top triggers, time of day)
   - Success rate calculation
   - Complete craving history

4. **Meditate** 🧘
   - Meditation timer (start/pause/resume)
   - Log past meditation
   - Streak tracking
   - Total time statistics
   - Session history with notes
   - 9 meditation types

5. **Calendar** 📅
   - Monthly calendar view
   - Event scheduling
   - Check-in indicators
   - Event details
   - Add/delete events

6. **Journal** 📖
   - Meetings log
   - Growth logs
   - Challenges tracker
   - Gratitude journal
   - Category navigation
   - Add/delete entries

7. **Contacts** 👥
   - Support network management
   - Quick-dial phone numbers
   - Email integration
   - Role labels (sponsor, friend, etc.)
   - Notes for each contact

8. **Analytics** 📊
   - Total entries count
   - Check-in streak
   - Meditation streak
   - Mood trend indicator
   - Activity breakdown by category
   - Monthly activity chart (6 months)
   - Milestone progress tracker

---

## 🛡️ Relapse Prevention Plan

### 5-Zone System

**Warning Signs**
- Personal indicators of risk
- Examples: isolation, mood changes, skipping meetings

**High-Risk Situations**
- Triggers to avoid
- Examples: people, places, events, emotions

**Green Zone - Maintenance**
- Daily healthy actions
- Examples: meetings, meditation, exercise

**Yellow Zone - Caution**
- Early intervention steps
- Examples: extra meetings, call sponsor, avoid triggers

**Red Zone - Emergency**
- Crisis protocols
- Examples: call sponsor NOW, emergency meeting, coping strategies

### How to Build Your Plan
1. Tap "My Prevention Plan" on Home tab
2. Select each zone
3. Add personalized items
4. Save and review regularly
5. Access quickly during crisis

---

## 🧘 Meditation Features

### Built-In Timer
- Start/pause/resume controls
- Real-time duration display
- Minimum 1 minute to log
- Complete with type selection

### Meditation Types
1. Mindfulness
2. Guided Meditation
3. Breathing Exercise
4. Body Scan
5. Loving-Kindness
6. Visualization
7. Walking Meditation
8. Mantra
9. Other

### Statistics
- Consecutive day streak
- Total minutes/hours
- Session history
- Integration with Analytics

---

## 😊 Mood Tracking

### 5-Level Scale
- 😢 Very Bad (1)
- 😟 Bad (2)
- 😐 Okay (3)
- 🙂 Good (4)
- 😄 Great (5)

### Features
- Set mood with daily check-in
- Update mood anytime
- Visual mood calendar
- Trend analysis (improving/declining/stable)
- Analytics integration

### Benefits
- Identify mood-craving patterns
- Early warning system
- Track emotional progress
- Share with therapist

---

## 🌙 Dark Mode

### Features
- Toggle on Home tab
- Smooth color transitions
- Persistent preference
- All components adapted
- Eye-friendly colors

### Color Schemes
- **Light**: Slate, blue, indigo with white backgrounds
- **Dark**: Purple, pink, blue with gray backgrounds

---

## 💾 Data Management

### Automatic Saving
- All data saves to localStorage
- No manual save needed
- Persists across sessions
- Includes all v4 features

### Export/Import
- **Export**: Download JSON backup
- **Import**: Restore from backup
- Includes all data:
  - Sobriety date
  - Check-ins with moods
  - Cravings
  - Meditations
  - Prevention plan
  - Meetings, growth, challenges, gratitude
  - Contacts and events
  - Dark mode preference

### Privacy
- All data stored locally
- No external servers
- No account required
- Complete privacy

---

## 🎯 Daily Workflow

### Morning
1. Open app
2. Complete daily check-in
3. Select current mood
4. Review prevention plan (Green Zone)

### Throughout Day
5. Log cravings if they occur
6. Use coping strategies
7. Check calendar for events

### Evening
8. Meditate for 10-15 minutes
9. Add gratitude entry
10. Review Analytics

### Weekly
11. Export data backup
12. Review mood trends
13. Update prevention plan
14. Check milestone progress

---

## 🆘 Emergency Support

### Quick Access
- "I Need Help Now" button on Check-In and Home tabs
- One-tap call to sponsor
- Emergency text messaging
- Crisis hotline (988)
- 10 coping strategies

### Coping Strategies Included
1. Deep Breathing
2. Call Your Sponsor
3. Go for a Walk
4. Play the Tape Forward
5. HALT Check
6. Gratitude List
7. Attend a Meeting
8. Read Recovery Literature
9. Distract Yourself
10. Remember Your Why

---

## 📊 Analytics Insights

### Metrics Tracked
- Total entries (all categories)
- Days sober
- Check-in streak
- Meditation streak
- Total meditation time
- Mood trend
- Meetings attended
- Growth logs
- Challenges overcome
- Gratitude entries
- Cravings logged
- Craving success rate

### Visualizations
- Activity breakdown bars
- Monthly activity chart
- Milestone progress
- Mood trend indicator
- Top triggers chart
- Time of day analysis

---

## 🔧 Technical Details

### Requirements
- **React**: 18+
- **Tailwind CSS**: Latest
- **Lucide React**: Latest (for icons)
- **Browser**: Modern browser with localStorage support

### Browser Compatibility
- ✅ Chrome/Edge
- ✅ Firefox
- ✅ Safari
- ✅ Mobile browsers (iOS/Android)

### File Size
- Component: ~120KB
- Demo HTML: ~3KB
- Documentation: ~20KB
- Total package: ~150KB

### Performance
- Instant load time
- No network requests (after initial load)
- Smooth animations
- Responsive on all devices

---

## 🎨 Design Philosophy

### User-Centered
- Clean, intuitive interface
- Large touch targets for mobile
- Clear visual hierarchy
- Consistent color coding

### Recovery-Focused
- Evidence-based features
- Therapist-recommended tools
- Crisis support prominent
- Positive reinforcement

### Accessible
- High contrast modes
- Clear labels
- Screen reader friendly
- Keyboard navigation

---

## 📈 Roadmap (Future Versions)

### v5 Planned Features
- Mood-craving correlation charts
- Meditation reminders
- Prevention plan alerts
- Mood journal with notes
- Guided meditation audio
- Dark mode auto-switch
- Cloud sync (optional)
- Multi-language support

---

## 🏆 Success Tips

### For Best Results
1. **Check in daily** - Build the habit
2. **Be honest with moods** - Track authentically
3. **Build your prevention plan** - Personalize it
4. **Meditate regularly** - Start with 5 minutes
5. **Log cravings immediately** - Don't wait
6. **Review analytics weekly** - Celebrate progress
7. **Export data regularly** - Backup your journey
8. **Share with sponsor** - Use as discussion tool

### Common Pitfalls to Avoid
- ❌ Skipping check-ins
- ❌ Not logging cravings (shame/embarrassment)
- ❌ Ignoring mood trends
- ❌ Not building prevention plan
- ❌ Forgetting to export data

---

## 🆘 Crisis Resources

### In-App
- Emergency Support button
- Quick-dial to sponsor
- 10 coping strategies
- Prevention plan Red Zone

### External
- **988 Suicide & Crisis Lifeline**: Call or text 988
- **SAMHSA National Helpline**: 1-800-662-4357 (24/7)
- **Crisis Text Line**: Text HOME to 741741
- **AA Hotline**: Check local area
- **NA Hotline**: Check local area

---

## 📖 Documentation

### Included Files
- **V4_FEATURES.md**: Comprehensive feature guide (15+ pages)
- **README.md**: This overview and quick start guide

### Topics Covered
- Feature descriptions
- How-to guides
- Best practices
- Technical details
- Data structure
- Migration guide
- Success stories

---

## 🙏 Acknowledgments

This app is built on evidence-based recovery principles from:
- Alcoholics Anonymous
- Narcotics Anonymous
- Cognitive Behavioral Therapy (CBT)
- Dialectical Behavior Therapy (DBT)
- Mindfulness-Based Relapse Prevention
- Relapse Prevention Therapy

---

## 📜 License & Usage

### Free to Use
- Personal recovery use
- Share with others in recovery
- Modify for your needs
- No attribution required

### Not a Replacement
- Not a substitute for professional treatment
- Not medical advice
- Supplement to, not replacement for, therapy/meetings
- Consult professionals for serious issues

---

## 💪 Final Words

**Recovery is possible. You are not alone.**

This app is a tool to support your journey, but **you** are the one doing the work. Every check-in, every meditation, every craving you overcome - that's all you.

**One day at a time.**

**Progress, not perfection.**

**You've got this.** 🌟

---

## 📞 Support

For technical issues, feature requests, or questions:
- Review the V4_FEATURES.md documentation
- Check your browser's console for errors
- Ensure localStorage is enabled
- Try exporting/importing data if issues persist

For recovery support:
- Contact your sponsor
- Attend a meeting
- Call a crisis hotline
- Reach out to your support network

---

**Version**: 4.0  
**Release Date**: October 2024  
**Component Size**: 2,500+ lines  
**Features**: 40+ tools and trackers  

**Stay strong. Keep going. You're worth it.** 💜

